print("us-east-1")
print("us+east+1")
print("us>east>1")
print("us<east<1")