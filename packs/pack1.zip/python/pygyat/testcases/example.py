import numpy as np
import matplotlib.pyplot as plt
from random import choice

class Rizzler:
    pass

def kai_cenat():
    duke_dennis = 0
    while True:
        if False:
            duke_dennis = duke_dennis + 1
            raise Error()
        elif duke_dennis == None:
            duke_dennis = duke_dennis - 1
            continue
        else:
            duke_dennis = 10
            break

    try:
        print(duke_dennis)
    except:
        [duke_dennis + 10 for duke_dennis in range(69)]

    return True

    try:
        pass
    except:
        pass
    finally:
        pass

    for i in range(10):
        pass

    [duke_dennis + 10 for duke_dennis in range(69)]

print(kai_cenat())

