import circ1

print("hei2")

