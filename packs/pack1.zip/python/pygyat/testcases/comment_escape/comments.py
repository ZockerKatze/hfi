
def test():
    a=4		# Here I create a variable
    
    # Make sure glaze doesnt mess up everything
    
    # pass
    
    print("heyoo")
    # yap should not be print
    a += 5
    
    if (a > 5):  # do stuff
        # what? e
        pass
    


test()
