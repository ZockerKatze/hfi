def test():# prints hello
    print("Hello!")

test()
