from pygyat.glaze import glaze
glaze("test_module", globals())

test_module.func()