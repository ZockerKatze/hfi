## personen beispiel

person = {"Name": "Jeremias", "Alter": 14,"Stadt": "Kaindorf"}

for key, value in person.items():
    print(f"{key}: {value}")

