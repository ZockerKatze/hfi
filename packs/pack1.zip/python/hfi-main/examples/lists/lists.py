wohnsachen = {"namen": "marian","hausnummer": "821", "straße": "kleinbesenstiel"}
for key, value in wohnsachen.items():
    print(f"{key}: {value}")
