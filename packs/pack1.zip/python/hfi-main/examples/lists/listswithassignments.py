import random
import pyfiglet
from termcolor import colored


## für das example ist das gut genug!
## ich weiß man sollte keine sehr langen listen machen jedoch ...

names = ["Bamy", "Jeremias", "Maxi", "Marian","Seppl","Niklas","Sascha","Elias","Herbert","Vandita","Mia","Melli","Anna","Ilya","Luzia","Marie","Mona","Marlene","Mykyta","Pia"]
idkk = ["Ist Gay", "Ist Lesbisch", "Ist Trans", "Ist schwarz","Ist ein Femboy","Hat eine Koffeinsucht","Hat eine Alk. sucht","Ist ein DiscordKitten","hat Herbert arschgefickt","muss sich selber eingraben"]



while names and idkk:
    # Randomly pick a name and a task
    name = random.choice(names)
    assignedthing = random.choice(idkk)

    input("Waiting for UserInput!") ## wenn das funktioniert werde ich jemanden den schwanz abhacken

    f = pyfiglet.figlet_format(name + " " + assignedthing)
    print(colored(f ,attrs=["bold"]))

## remove name for thing to not appear as a second time

    names.remove(name)
    idkk.remove(assignedthing)

print("give a black fellow a break")
