cd /home/rattatwingo/Desktop/python/hfi-main/examples/colorbye/
python3 /home/rattatwingo/Desktop/python/hfi-main/examples/colorbye/
