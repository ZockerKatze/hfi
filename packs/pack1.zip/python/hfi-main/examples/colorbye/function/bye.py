import asciiarg as aa

aa.RAP("Bye Bye! :3")

input("ENTER TO EXIT: ")
