import random
import pyfiglet

names = ["Anna","Bamy","Elias","Ilya","Jeremias","Luzia","Marie","Mia","Mona","Niklas","Sascha","Maxi","Vandi","Marlene","Lena","Pia","Melli","Herbert","Marian","Seppl"]
adjectives = ["gay","klein","dumm","ausländerfeindlich","femboy","einstein","eine Erdnuss","ein Fruchtzwerg","ein wixxer","Trans","ein Huransohn","ein Test-User","witzig","ein eierlecker","lesbisch"]

while names and adjectives:
    try:
        r_names = random.choice(names)
        r_adje = random.choice(adjectives)

    #figlet ascii (optional)

        f = pyfiglet.figlet_format(r_names + " ist " + r_adje)
        input("ENTER: ") ## opt.
        print(f)

    ## entfernt die randomisierte auswahl aus der liste

        names.remove(r_names)
        adjectives.remove(r_adje)
    except KeyboardInterrupt:
        print("\nendp")
        break

exit()
