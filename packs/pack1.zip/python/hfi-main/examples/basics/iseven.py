def is_even(num):
    if num % 2 != 0:
        print("Is not Even!")
    else:
        print("Number is Even!")

is_even(1020423)

## checks for number 6
## returns IS EVEN!
## if not 6 or even number then not print even!
## very basic example of the use of modulo used in math too!

