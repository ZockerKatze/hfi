inta = 1
floata = 1.35836493674363
stra = "marian hat sehr kleine klöten"


print(f"int: {inta}, floata: {floata}, str: {stra}")
