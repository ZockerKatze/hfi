import colorama
from colorama import Fore
import pyfiglet

colorama.init(autoreset=True)

rainbow_colors = [Fore.RED, Fore.YELLOW, Fore.GREEN, Fore.CYAN, Fore.BLUE, Fore.MAGENTA]

def RAP(text):
    def rainbowtext(text):
        colored_text = ""
        for i, char in enumerate(text):
            color = rainbow_colors[i % len(rainbow_colors)]
            colored_text += f"{color}{char}"
        return colored_text


    def printtext():
        print()

    def asciiart(input_text):
        asciiart = pyfiglet.figlet_format(input_text)
        return asciiart

    asciiart(text)
    rainbowascii = rainbowtext(asciiart)
    printtext(rainbowascii)
RAP("marian ist ein huso und kann nix")
