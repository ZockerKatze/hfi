import pyfiglet

def numfunc(num):
    numnew = str(num)
    f = pyfiglet.figlet_format(numnew)
    print(f)


numfunc(12)
