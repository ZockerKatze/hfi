import random
import pyfiglet

def kickfunc():
    while True:
        try:
            rng = random.randint(1,10)
            ct += 1
            if rng > 5:
                f = pyfiglet.figlet_format("KICK!")
                print(f)
            else:
                f = pyfiglet.figlet_format("NO KICK!")
                print(f)
        except ct == 10:
            break

kickfunc()
