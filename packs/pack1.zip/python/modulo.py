def i_even(num):
    if num % 2 == 0:
        print("Gerade")
    else:
        print("nix gerade")


i_even(9)
