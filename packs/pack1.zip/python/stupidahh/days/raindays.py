import os
import pyfiglet
from termcolor import colored

def raintext(text):
    colors = ["red", "yellow", "green", "cyan", "blue", "magenta"]
    ro = "" #ro nix
    for i, char in enumerate(text):
        if char.strip():  # leerzeilen
            color = colors[i % len(colors)]
            ro += colored(char, color)
        else:
            ro += char
    return ro

def main():
    DAYF = "rainct.txt" ## DAYF is now the counterfile

    if os.path.exists(DAYF): ## schaut mal ob dayf existiert
        with open(DAYF, "r") as file:
            try:
                cday = int(file.read().strip()) ## öffnet
            except ValueError:
                cday = 0 ## wenn 0 gs
    else:
        cday = 0

    cday += 1 ## +1 auf cday counter

    with open(DAYF, "w") as file:
        file.write(str(cday)) ## string idk why? das ist ne int

    figlet = pyfiglet.Figlet(font="slant")  
    ascii_art = figlet.renderText(f"Tag: {cday}")
    
    rainbow_art = "\n".join(raintext(line) for line in ascii_art.splitlines()) ## join funtionrainbowtext for line with current asciiart ?
    
    print(rainbow_art)
main() ## call funtion defined at ln16
