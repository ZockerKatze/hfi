import os
import pyfiglet
from termcolor import colored
import shutil

def raintext(text):
    colors = ["red", "yellow", "green", "cyan", "blue", "magenta"]
    ro = ""  # Rain text output
    for i, char in enumerate(text):
        if char.strip():  # Skip whitespace-only characters
            color = colors[i % len(colors)]
            ro += colored(char, color)
        else:
            ro += char
    return ro

def main():
    DAYF = "rainct.txt"  # Counter file

    if os.path.exists(DAYF):  # Check if file exists
        with open(DAYF, "r") as file:
            try:
                cday = int(file.read().strip())  # Read current day count
            except ValueError:
                cday = 0  # Reset to 0 if invalid
    else:
        cday = 0

    cday += 1  # Increment day count

    with open(DAYF, "w") as file:
        file.write(str(cday))  # Write updated count

    figlet = pyfiglet.Figlet(font="slant")
    ascii_art = figlet.renderText(f"Tag: {cday}")

    # Centering the text
    terminal_width = shutil.get_terminal_size().columns
    rainbow_art = "\n".join(
        raintext(line.center(terminal_width)) for line in ascii_art.splitlines()
    )

    print(rainbow_art)

main()
