import pyfiglet
import daysclicenter as dayfunc
import shutil

context = str(input("TODAY?: "))
def callascii():
    gayy = pyfiglet.Figlet()
    gayyart = gayy.renderText(context)
    terminal_weite = shutil.get_terminal_size().columns
    art_center = "\n" .join(
        (line.center(terminal_weite)) for line in gayyart.splitlines()
    )
    print(art_center)
    try:
        e = str(input("Waiting for Keypress! ..."))
    except KeyboardInterrupt:
        exit()
callascii()
