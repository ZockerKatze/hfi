import random ## random module
rand = random.randint(1,10) # generate random num
tryct=1 ## legt base wert fest
M=1.2 ## legt base wert fest (float) weil sonst vielleicht programm schon bei try01 exited
while M != rand: ## schleife != (NICHT GLEICH) d.h. wenn m != rand dann weitermachen
    try: ## während wahr mache try:
        print(f"Versuch {tryct}") ## gibt die versuche aus
        M = int(input("INTEGER 1-10: ")) ## einfacher INT input (1,3,4,5,6,7,8,9,10)
        tryct+=1 ## fügt bei tryct 1 hinzu += weil + während = (assign)
        if tryct > 10: ## wenn tryct > 10 raus
            print("versuche überschritten")
            break ## aus schleife / programm gehen
        else: ## wenn tryct nicht >10 weiter
            continue ##weiter mit programm (bei try:)
    except KeyboardInterrupt: ## wenn strg + c dann raus
        break ## raus
        print(f"rand {rand}")  # die zahl wäre rand gewesen

## einfaches ratespiel (erkl auf yt!)
