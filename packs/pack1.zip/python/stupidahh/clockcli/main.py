import sys
sys.stdout.write("\x1b[8;{rows};{cols}t".format(rows=11, cols=50)) ##yanked from so!
import datetime
import os     
import time 
import shutil
from datetime import date # idk wtf
from colorama import Back , Fore , Style
import random 

try:
    from pyfiglet import figlet_format  
    from termcolor import colored
except ImportError:
    print('Error, modules pyfiglet and termcolor are required. Run: pip install pyfiglet termcolor')
    exit(1)

levl_update_frequency = 3
time_format = '%H ⋮ %M ⋮ %S'
last_levl_update = time.time()
update_frequency = 1

rainbow_colors = ['red', 'yellow', 'green', 'cyan', 'blue', 'magenta']

timevar = str(date.today())

def rainbow_text(text):
    colored_text = ""
    for i, char in enumerate(text):
        color = rainbow_colors[i % len(rainbow_colors)]
        colored_text += colored(char, color)
    return colored_text

levl = 0

def sl():
    return random.randint(1,100)

while True:
    os.system('clear' if os.name == 'posix' else 'cls')
    terminal_width = shutil.get_terminal_size().columns
    time_string = datetime.datetime.now().strftime(time_format)
    figlet_string = figlet_format(time_string)
    colored_ascii = '\n'.join(rainbow_text(line) for line in figlet_string.split('\n'))
    centered_ascii = '\n'.join(line.center(terminal_width) for line in colored_ascii.split('\n'))
    
    if time.time() - last_levl_update >= levl_update_frequency:
        levl = sl()
        last_levl_update = time.time()

    print(centered_ascii)
    print("╠Heute ist ⋙ ", Back.GREEN + Fore.BLACK + timevar, Style.RESET_ALL + "╣\n")
    print("Schizolevel ⋙ ",levl,"%\n")
    time.sleep(update_frequency)
