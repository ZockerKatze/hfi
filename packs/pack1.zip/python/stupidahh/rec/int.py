import random

herbert = random.randint(1,10) ## 1-10 randomnumber
mayran = 1 ## trycounter var
M=11
while M != herbert:
    try:
        print(f"Versuch: {mayran}") ## f ist für fun
        M = int(input("Integer (Ganzzahlinput) 1-10:"))
        mayran += 1
        if mayran > 10:
            print("Du hast die Versuche überschitten")
            break ## rausgehen aus der loop
        else:
            continue ## continue == weitermachen mit sachen
    except KeyboardInterrupt: ## strg + c == exit
        exit()
