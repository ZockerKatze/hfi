import random
from colorama import Fore, Back, Style


herbert = 1  ## ist versuche
idk = random.randint(1,10)  # random zahl zwischen 1-10

while herbert < 10:
    try:
        print(f"Versuche: {herbert}") ## versuche println
        jj = int(input("Zahl zwischen 1-10 int: "))
        herbert += 1 ## bei jeder loop wird herbert um 1 incrementiert
        if jj == idk:
            print(Fore.GREEN + "Du hast gebonnen!")
            print(Style.RESET_ALL)
            break
        else:
            print(Fore.RED + "Leider daneben!")
            print(Style.RESET_ALL)
            continue
    except KeyboardInterrupt:   #beendet programm bei strg + c
        exit()
