import turtle

length=100
size =400
colors=['red','orange','yellow','blue','Indingo','violet'] ## indigo hört sich gay an xD

manfred = turtle.Turtle() ##initialisiert die turtle --> legt manfred fest

manfred.speed(10) ## geschwindigkeit der turtle
manfred.pensize(10)

for i in colors:
    manfred.penup()
    manfred.goto(-size/2,size/10)
    manfred.pendown()
    manfred.color(i)
    manfred.begin_fill()

    for j in range(5):
        manfred.fd(size) ##fd » forward (ist bei viele einfach ne abr.)
        manfred.rt(144) ## auch hier » aber steht für right
    manfred.end_fill()

manfred.mainloop()  ##manfreds leben <3
