import turtle

manfred = turtle.Turtle()

manfred.speed(20)
manfred.color("black","orange")
manfred. begin_fill()

for i in range (50):
    manfred.forward(300)
    manfred.left(170)

manfred.end_fill()
turtle.done()
