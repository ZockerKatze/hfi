## input
## st0
## ende


